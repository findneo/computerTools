https://bbs.pediy.com/thread-215669.htm

2018/09/29 更新

1. 安装原版软件：Source Insight Version 4.0.0096 - September 26, 2018 
(https://s3-us-west-2.amazonaws.com/assets.sourceinsight.com/download/v4/release/sourceinsight4096-setup.exe)

2. 替换原主程序：sourceinsight4.exe

3. 导入授权文件(Import a new license file)：si4.pediy.lic



sourceinsight4096.rar

     Size     Date    Time   Checksum  Name
---------  ---------- -----  --------  ----
  2887664  2018-09-26 18:22  AEB2CDBD  sourceinsight4.exe